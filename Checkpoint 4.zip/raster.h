/*
File Name: raster.h
Authors: Muhammad Abdullah, Nicholas Christie, Rohan Pernitsky

Declares framebuffer clearing, primitive drawing, bitmap plotting,
and font rendering routines.
*/

#ifndef RASTER_H
#define RASTER_H

#include "TYPES.H"

#define FRAMEBUFFER_WORD_COUNT 8000
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 400

#define BITS_PER_BYTE 8
#define WORD_BIT_COUNT 16
#define LONG_BIT_COUNT 32

#define BYTES_PER_SCANLINE 80
#define WORDS_PER_SCANLINE 40
#define LONGS_PER_SCANLINE 20

/*----- Function: clearScreen -----

 PURPOSE: Clears the entire screen.

 INPUT: Address(UINT32*): to the start of the screen

 OUTPUT: None

*/
void clearScreen(UINT32 *base);


/*----- Function: clearRegion -----

 PURPOSE: Clear a region of the screen. The section is specified by the coordinates of the top left corner, and the height and width of the region.

 INPUT: Address(UINT32*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the region
        Length: the lenth (number of rows) in pixels of the region
        Width: the width (number of columns) in pixels of the region

 OUTPUT: None

*/
void clearRegion(UINT32 *base, int row, int col, UINT16 length, UINT16 width);


/*----- Function: plotPixel -----

 PURPOSE: Plots a single pixel on the screen.

 INPUT: Address(UINT8*): to the start of the screen
        Position(row,col): the location of the pixel to plot

 OUTPUT: None

*/
void plotPixel(UINT8 *base, int row, int col);


/*----- Function: plotHorizontalLine -----

 PURPOSE: Plot a hoizontal line on the screen. The horizontal line is specified by the leftmost pixel of the line and the length of the line.

 INPUT: Address(UINT32*): to the start of the screen
        Position(row,col): the coordinates of the leftmost pixel of the horizontal line
        Length: the lenth in pixels of the line

 OUTPUT: None
*/
void plotHorizontalLine(UINT32 *base, int row, int col, UINT16 length);


/*----- Function: plotVerticalLine -----

 PURPOSE: Plot a hoizontal line on the screen. The vertical line is specified by the topmost pixel of the line and the length of the line.

 INPUT: Address(UINT32*): to the start of the screen
        Position(row,col): the coordinates of the topmost pixel of the vertical line
        Length: the lenth in pixels of the line

 OUTPUT: None
*/
void plotVerticalLine(UINT32 *base, int row, int col, UINT16 length);


/*----- Function: plotLine -----

 PURPOSE: Plots a line on the screen between the two given points.

 INPUT: Address(UINT32*): to the start of the screen
        Position(start_row,start_col): the coordinates of the start of the line
        Position(end_row,end_col): the coordinates of the end of the line

 OUTPUT: None
*/
void plotLine(UINT32 *base, int start_row, int start_col, int end_row, int end_col);


/*----- Function: plotRectangle -----

 PURPOSE: Plots a rectangle on the screen given by the top left pixel, and the length and width of the rectangle.

 INPUT: Address(UINT32*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the rectangle
        Length: the lenth (number of rows) in pixels of the rectangle
        Width: the width (number of columns) in pixels of the rectangle

 OUTPUT: None
*/
void plotRectangle(UINT32 *base, int row, int col, UINT16 length, UINT16 width);


/*----- Function: plotSquare -----

 PURPOSE: Plots a square on the screen given by the top left pixel, and the length of the sides of the square.

 INPUT: Address(UINT32*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the square
        Side: the lenth of each side, in pixels, of the square

 OUTPUT: None
*/
void plotSquare(UINT32 *base, int row, int col, UINT16 side);


/*----- Function: plotTriangle -----

 PURPOSE: Plots a triangle on the screen given by the coordinate of the 90° angle, the length of the base, the length of the height, and the direction of the triangle.

 INPUT: Address(UINT32*): to the start of the screen
        Position(row,col): the coordinates of the pixel of the 90° angle of the triangle
        Base: the length (number of columns) of the base in pixels of the triangle
        Height: the lenth (number of rows) of the height in pixels of the triangle
        Direction: Describes where the coordinate is relative to the rest of the triangle
              0 - Coordinate is the top left point of the triangle
              1 - Coordinate is the top right point of the triangle
              2 - Coordinate is the bottom left point of the triangle
              3 - Coordinate is the bottom right point of the triangle


 OUTPUT: None
*/
void plotTriangle(UINT32 *base, int row, int col, UINT16 triangle_base, UINT16 height, UINT8 direction);


/*----- Function: plot8bitBitmap -----

 PURPOSE: Plots a bitmap to the screen given by the top left pixel of the bitmap and the height of bitmap.

 INPUT: Address(UINT8*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the bitmap
        Height: the lenth (number of rows) of the height in pixels of the bitmap

 OUTPUT: None
*/
void plot8bitBitmap(UINT8 *base, int row, int col, const UINT8 *bitmap, UINT16 height);


/*----- Function: plot16bitBitmap -----

 PURPOSE: Plots a bitmap to the screen given by the top left pixel of the bitmap and the height of bitmap.

 INPUT: Address(UINT16*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the bitmap
        Height: the lenth (number of rows) of the height in pixels of the bitmap

 OUTPUT: None
*/
void plot16bitBitmap(UINT16 *base, int row, int col, const UINT16 *bitmap, UINT16 height);


/*----- Function: plot32bitBitmap -----

 PURPOSE: Plots a bitmap to the screen given by the top left pixel of the bitmap and the height of bitmap.

 INPUT: Address(UINT32*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the bitmap
        Height: the lenth (number of rows) of the height in pixels of the bitmap

 OUTPUT: None
*/
void plot32bitBitmap(UINT32 *base, int row, int col, const UINT32 *bitmap, UINT16 height);


/*----- Function: plotCharacter -----

 PURPOSE: Plots a single character, as a bitmap from a font table, to the screen.

 INPUT: Address(UINT8*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the character
        ch(char): the character to be written to the screen

 OUTPUT: None
*/
void plotCharacter(UINT8 *base, int row, int col, char ch);


/*----- Function: plotString -----

 PURPOSE: Plots a string, as a sequence of bitmaps from a font table, to the screen.

 INPUT: Address(UINT8*): to the start of the screen
        Position(row,col): the coordinates of the top left pixel of the string
        ch(c-string): the string to be written to the screen

 OUTPUT: None
*/
void plotString(UINT8 *base, int row, int col, char *ch);

#endif
